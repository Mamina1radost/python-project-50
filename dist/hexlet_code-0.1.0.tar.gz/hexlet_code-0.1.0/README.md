### Hexlet tests and linter status:
[![Actions Status](https://github.com/Mamina1radost/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Mamina1radost/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/06ee9e704a14176e1ce0/maintainability)](https://codeclimate.com/github/Mamina1radost/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/06ee9e704a14176e1ce0/test_coverage)](https://codeclimate.com/github/Mamina1radost/python-project-50/test_coverage)