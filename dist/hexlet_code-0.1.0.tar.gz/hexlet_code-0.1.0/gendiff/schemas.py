from typing import TypedDict


class JsonObject(TypedDict):
    pass


class YamlObject(TypedDict):
    pass
